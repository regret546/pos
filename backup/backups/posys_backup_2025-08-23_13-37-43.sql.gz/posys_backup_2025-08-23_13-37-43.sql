mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: posystem
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Category` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'KEYBOARD','2025-08-22 01:37:19'),(2,'MOUSE','2025-08-22 01:37:27'),(3,'CPU','2025-08-22 01:37:31');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `idDocument` int NOT NULL,
  `email` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `phone` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `birthdate` date NOT NULL,
  `purchases` int NOT NULL,
  `lastPurchase` datetime NOT NULL,
  `registerDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Gab',21312,'jkduran1998@gmail.com','09559332133','Bunao1','2022-02-22',6,'2025-08-23 20:17:57','2025-08-23 12:17:57'),(2,'Queen',32423,'','09559332133','Bunao','1900-01-01',2,'2025-08-23 20:26:45','2025-08-23 12:26:45'),(3,'Queen',3434,'','09559332133','Cebu','1900-01-01',0,'2025-08-22 09:36:52','2025-08-22 01:36:52'),(4,'John',3434,'','09559332133','Cebu','1900-01-01',1,'2025-08-23 20:19:05','2025-08-23 12:19:05');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installment_payments`
--

DROP TABLE IF EXISTS `installment_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installment_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `installment_plan_id` int NOT NULL,
  `payment_number` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('pending','paid','overdue') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `installment_plan_id` (`installment_plan_id`),
  CONSTRAINT `fk_payment_plan` FOREIGN KEY (`installment_plan_id`) REFERENCES `installment_plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installment_payments`
--

LOCK TABLES `installment_payments` WRITE;
/*!40000 ALTER TABLE `installment_payments` DISABLE KEYS */;
INSERT INTO `installment_payments` VALUES (29,45,1,200.00,'2025-09-15','2025-08-23','paid','2025-08-23 12:19:05'),(30,45,2,200.00,'2025-09-30',NULL,'pending','2025-08-23 12:19:05'),(31,45,3,200.00,'2025-10-15',NULL,'pending','2025-08-23 12:19:05'),(32,45,4,200.00,'2025-10-30',NULL,'pending','2025-08-23 12:19:05'),(34,46,1,450.00,'2025-09-30','2025-08-23','paid','2025-08-23 12:26:45'),(35,46,2,250.00,'2025-10-30','2025-08-23','paid','2025-08-23 12:26:45'),(36,44,1,71.27,'2025-09-15','2025-08-23','paid','2025-08-23 12:35:26'),(37,44,2,67.54,'2025-10-15',NULL,'pending','2025-08-23 12:35:26'),(38,44,3,71.27,'2025-11-15',NULL,'pending','2025-08-23 12:35:26'),(39,44,4,71.27,'2025-12-15',NULL,'pending','2025-08-23 12:35:26'),(40,44,5,71.27,'2026-01-15',NULL,'pending','2025-08-23 12:35:26'),(41,44,6,71.27,'2026-02-15',NULL,'pending','2025-08-23 12:35:26');
/*!40000 ALTER TABLE `installment_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installment_plans`
--

DROP TABLE IF EXISTS `installment_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installment_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `bill_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `customer_id` int NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `base_amount` decimal(10,2) NOT NULL,
  `number_of_payments` int NOT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `payment_frequency` enum('15th','30th','both') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '30th',
  `start_date` date NOT NULL,
  `status` enum('active','completed','defaulted') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `downpayment_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'Amount paid as downpayment',
  `remaining_amount` decimal(10,2) GENERATED ALWAYS AS ((`total_amount` - `downpayment_amount`)) STORED COMMENT 'Amount remaining for installments after downpayment',
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `customer_id` (`customer_id`),
  KEY `idx_downpayment_amount` (`downpayment_amount`),
  KEY `idx_remaining_amount` (`remaining_amount`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installment_plans`
--

LOCK TABLES `installment_plans` WRITE;
/*!40000 ALTER TABLE `installment_plans` DISABLE KEYS */;
INSERT INTO `installment_plans` (`id`, `sale_id`, `bill_number`, `customer_id`, `total_amount`, `base_amount`, `number_of_payments`, `payment_amount`, `interest_rate`, `payment_frequency`, `start_date`, `status`, `created_at`, `downpayment_amount`) VALUES (44,5,'10005',1,627.60,627.60,6,71.27,0.00,'15th','2025-08-23','active','2025-08-23 12:17:57',200.00),(45,6,'10006',4,1000.00,1000.00,4,200.00,0.00,'both','2025-08-23','active','2025-08-23 12:19:05',200.00),(46,7,'10007',2,1100.00,1100.00,2,450.00,0.00,'30th','2025-08-23','completed','2025-08-23 12:26:45',200.00);
/*!40000 ALTER TABLE `installment_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idCategory` int NOT NULL,
  `code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `image` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `stock` int NOT NULL,
  `buyingPrice` float NOT NULL,
  `sellingPrice` float NOT NULL,
  `sales` int NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'34242','Aula f75','views/img/products/default/anonymous.png',20,400,560,0,'2025-08-22 01:38:01'),(2,3,'213123','Product2-1','views/img/products/default/anonymous.png',52,800,1120,5,'2025-08-23 12:26:45'),(3,1,'343434--','asdasd','views/img/products/default/anonymous.png',231,234,327.6,3,'2025-08-23 12:17:57');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` int NOT NULL,
  `idCustomer` int NOT NULL,
  `idSeller` int NOT NULL,
  `products` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `tax` int NOT NULL,
  `discount` decimal(10,2) DEFAULT '0.00',
  `netPrice` float NOT NULL,
  `totalPrice` float NOT NULL,
  `customerCash` float DEFAULT NULL,
  `paymentMethod` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `saledate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,10001,1,1,'[{\"id\":\"2\",\"description\":\"asdasdas\",\"quantity\":\"1\",\"stock\":\"56\",\"price\":\"1120\",\"totalPrice\":1120}]',0,120.00,1000,1000,NULL,'cash','2025-08-22 01:38:36'),(2,10002,2,1,'[{\"id\":\"2\",\"description\":\"asdasdas\",\"quantity\":\"1\",\"stock\":\"55\",\"price\":\"1120\",\"totalPrice\":1120}]',0,120.00,1000,1000,NULL,'cash','2025-08-23 12:17:06'),(3,10003,1,1,'[{\"id\":\"3\",\"description\":\"asdasd\",\"quantity\":\"1\",\"stock\":\"233\",\"price\":\"327.6\",\"totalPrice\":327.6}]',0,20.00,307.6,307.6,NULL,'cash','2025-08-23 12:17:03'),(4,10004,1,1,'[{\"id\":\"2\",\"description\":\"Product2-1\",\"quantity\":\"1\",\"stock\":\"54\",\"price\":\"1120\",\"totalPrice\":1120}]',0,120.00,1000,1000,NULL,'cash','2025-08-23 12:17:00'),(5,10005,1,1,'[{\"id\":\"3\",\"description\":\"asdasd\",\"quantity\":\"2\",\"stock\":\"231\",\"price\":\"327.6\",\"totalPrice\":655.2}]',0,27.60,627.6,627.6,NULL,'installment','2025-08-23 12:35:26'),(6,10006,4,1,'[{\"id\":\"2\",\"description\":\"Product2-1\",\"quantity\":\"1\",\"stock\":\"53\",\"price\":\"1120\",\"totalPrice\":1120}]',0,120.00,1000,1000,NULL,'installment','2025-08-23 12:19:05'),(7,10007,2,1,'[{\"id\":\"2\",\"description\":\"Product2-1\",\"quantity\":\"1\",\"stock\":\"52\",\"price\":\"1120\",\"totalPrice\":1120}]',0,20.00,1100,1100,NULL,'installment','2025-08-23 12:26:45');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `user` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `password` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `profile` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `photo` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `status` int NOT NULL,
  `lastLogin` datetime NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','admin','$2a$07$asxx54ahjppf45sd87a5auXBm1Vr2M1NV5t/zNQtGHGpS5fFirrbG','Administrator','views/img/users/admin/admin-icn.png',1,'2025-08-23 20:08:03','2025-08-23 12:08:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'posystem'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-23 21:37:43
